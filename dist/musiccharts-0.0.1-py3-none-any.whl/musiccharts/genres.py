# this list is not auto updated, so here could be some outdated data
# but this will be made auto updated soon

DRUM_AND_BASS = 1
HARD_TECHNO = 2
ELECTRONICA = 3

HOUSE = 5
TECHNO = 6
TRANCE = 7
HARD_DANCE_AND_HARDCODE = 8
BREAKS_AND_BREAKBEAT_AND_UK_BASS = 9

TECH_HOUSE = 11
DEEP_HOUSE = 12
PSY_TRANCE = 13
MINIMAL_AND_DEEP_TECH = 14
PROGRESSIVE_HOUSE = 15
DJ_TOOLS = 16
# ELECTRO_HOUSE = 17
DUBSTEP = 18

ALL_GENRES = [DRUM_AND_BASS,
              HARD_TECHNO,
              ELECTRONICA,

              HOUSE,
              TECHNO,
              TRANCE,
              HARD_DANCE_AND_HARDCODE,
              BREAKS_AND_BREAKBEAT_AND_UK_BASS,

              TECH_HOUSE,
              DEEP_HOUSE,
              PSY_TRANCE,
              MINIMAL_AND_DEEP_TECH,
              PROGRESSIVE_HOUSE,
              DJ_TOOLS,
              # ELECTRO_HOUSE,
              DUBSTEP]
